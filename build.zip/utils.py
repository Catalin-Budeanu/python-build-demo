def calculate_total(prices):
    """Returnează suma totală a prețurilor."""
    if not prices:
        return 0
    return sum(prices)
