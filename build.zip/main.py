from utils import calculate_total

if __name__ == "__main__":
    prices = [10, 15, 25]
    total = calculate_total(prices)
    print(f"Totalul este: {total} RON")
